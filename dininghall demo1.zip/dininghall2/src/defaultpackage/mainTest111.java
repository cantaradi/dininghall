package defaultpackage;

import java.util.List;
import com.station.dao.*;
import com.station.model.*;


public class mainTest111 {
	public static void main(String[] args) {
		Dininghall zoo = new Dininghall();
		Manager pig = new Manager(zoo);
	}
}