package com.station.model;
import java.awt.*;




import javax.swing.*; 


import com.station.model.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.stream.Collectors;
public class Manager extends JFrame implements ActionListener{
	/*@
	  @ public invariant manager_id != null;
	  @ public invariant (\forall int i; 0 <= i && i<m_dininghall.ManInfo.size();
	  @   (\forall int j; 0 <= j && j< m_dininghall.ManInfo.size();
	  @       m_dininghall.ManInfo.get(j) != m_dininghall.ManInfo.get(i) 
	  @           ==> m_dininghall.ManInfo.get(j).manager_id != m_dininghall.ManInfo.get(i).manager_id));
	  @*/
	public String manager_id;
	public Dininghall m_dininghall;
	JLabel label;
	JLabel label2;
	JTextField datetext;
	JButton uploadmenuBt;
	JButton confirmBt;
	JButton cancelBt;
	JPanel menuPanel;

	public Manager(Dininghall hall){
		m_dininghall = hall;
		m_dininghall.ManInfo.add(this);
		uploadmenuBt = new JButton("Upload menu");
		uploadmenuBt.setSize(170, 130);
		uploadmenuBt.setLocation(50, 130);
		this.add(uploadmenuBt);
		confirmBt=new JButton("confirm");
		confirmBt.setSize(100,30);
		confirmBt.setLocation(40, 240);
		confirmBt.addActionListener(this);
		this.add(confirmBt);
		confirmBt.setVisible(false);
		cancelBt=new JButton("cancel");
		cancelBt.setSize(100,30);
		cancelBt.setLocation(180, 240);
		cancelBt.addActionListener(this);
		this.add(cancelBt);
		cancelBt.setVisible(false);
		
		datetext=new JTextField();
		datetext.setSize(100,30);
		datetext.setLocation(200, 120);
		this.add(datetext);
		datetext.setVisible(false);
		
		label = new JLabel("Please enter today's date:");
		label.setSize(190, 190);
		label.setLocation(30, 40);
		this.add(label); 
		label.setVisible(false);
		
		label2 = new JLabel("Menu has already been generated for today, no more upload menu operation for today.");
		label2.setSize(700, 200);
		label2.setLocation(30, 40);
		this.add(label2); 
		label2.setVisible(false);
		
		menuPanel = new JPanel();
		menuPanel.setVisible(false);
		this.add(menuPanel);
		this.setSize(330,440);
		this.setVisible(true);
		uploadmenuBt.addActionListener(this);
		

		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bt=(JButton)e.getSource();
		if(bt.getText().equals("Upload menu"))
		{
			bt.setVisible(false);
			confirmBt.setVisible(true);
			cancelBt.setVisible(true);
			datetext.setVisible(true);
			label.setVisible(true);
		}
		else if(bt.getText().equals("confirm")){
			bt.setVisible(false);
			cancelBt.setVisible(false);
			datetext.setVisible(false);
			label.setVisible(false);
			this.setSize(600,600);
			int date = Integer.parseInt(datetext.getText().toString());
			m_dininghall.upload_menu(manager_id, date);
			menuPanel.setLayout(new GridLayout(5, 5, 10, 10));
			for(Dish dish : m_dininghall.MenuInfo) 
			{
				JPanel card = makeMakepanel(dish);
				menuPanel.add(card);
			}
			JButton submitButton = new JButton("submit");
			submitButton.setSize(300,300);
			menuPanel.add(submitButton);
			menuPanel.setVisible(true);
			submitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	JOptionPane.showMessageDialog(null, "Today's menu has been generated successfully!", "SUCCESS",JOptionPane.PLAIN_MESSAGE);
	            	menuPanel.setVisible(false);
	            	label2.setVisible(true);
	            	
	            }
	        });
			
		}
		else if(bt.getText().equals("cancel")){
			bt.setVisible(false);
			confirmBt.setVisible(false);
			datetext.setVisible(false);
			label.setVisible(false);
			uploadmenuBt.setVisible(true);
		}
	}
	
	private String GetDishProductName(Dish dish) 
	{
		String str = "ingredients:";
		for(Integer c : dish.Consumption.keySet() ) 
		{
			Ingredient pro = m_dininghall.products.stream().filter((Ingredient p) -> p.in_id == c.intValue()).collect(Collectors.toList()).get(0);	
			if(str == "ingredients:") 
			{
				str += pro.in_name;
			}
			else 
			{
				str += ", " + pro.in_name;
			}
			
		}
		return str;
	}
	
	public JPanel makeMakepanel(Dish dish) 
	{
		
		JPanel MenuCard = new JPanel(new GridLayout(3, 1, 10, 10));
		MenuCard.setSize(600, 600);
		
		JLabel dish_name = new JLabel();
		dish_name.setText(dish.dish_name);
		MenuCard.add(dish_name);
		
		JLabel dish_component = new JLabel();
		dish_component.setText(GetDishProductName(dish));
		MenuCard.add(dish_component);
		
		JLabel dish_quantity = new JLabel();
		dish_quantity.setText("dish quantity:" + String.valueOf(dish.quantity));
		MenuCard.add(dish_quantity);

		MenuCard.add(dish_quantity, BorderLayout.CENTER);
		MenuCard.setBackground(Color.WHITE);
		MenuCard.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try 
				{
					if(m_dininghall.menu.if_includedish(dish.dish_id)) 
					{   
						JOptionPane.showMessageDialog(null, "The dish already exists in the menu. Can't add it again!", "ERROR",JOptionPane.ERROR_MESSAGE); 
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Add the dish " + dish.dish_name + " to the menu successfully!", "SUCCESS",JOptionPane.PLAIN_MESSAGE);
						m_dininghall.menu.add_dish(dish.dish_id);
					}
				}
				catch(Exception e)
				{
					System.out.println(e.toString());
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				MenuCard.setBackground(Color.WHITE);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}
			});
		return MenuCard;
	}
}
