package com.station.model;
import java.util.ArrayList;



import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import com.station.dao.SqlTest;
import com.station.model.*;
public class Dininghall {
	public String dininghall_name="dininghall1";
	public ArrayList<Manager> ManInfo = new ArrayList<Manager>();
	public static List<Dish> MenuInfo = new ArrayList<Dish>();
	public /*@ nullable @*/ Menu menu = new Menu();
	public List<Ingredient> products;
	/**
	 * The upload menu function is used by the manager to choose dishes for today and generate today's menu. 
	 * This method starts when a manager logs into her account, clicks the “Upload menu” button and enters today’s date in her terminal. 
	 * This method ends when a menu including all the dishes chosen by the manager is formed
	 * @param mid
	 * @param date
	 * @return void
	 */
	/*@
	  @ requires date > 0;
	  @ requires (\exists Manager m; m.manager_id == mid);
	  @ requires menu.menu_content == null;
	  @ ensures menu.menu_id == date;
	  @ ensures DefaultDishes.DishesList.containsAll(menu.menu_content);
	  @ ensures (\forall int i; 0 <= i && i<menu.menu_content.size(); 
	  @    menu.if_includedish(menu.menu_content.get(i).dish_id) && menu.menu_content.get(i).quantity > 0);
	 @*/
	public void upload_menu(String mid, int date) 
	{
		menu.menu_id = date; 
		SqlTest sql = new SqlTest();
		this.products =  sql.select(1);
		ArrayList<Dish> Formula = DefaultDishes.DishesList; 
		for(int i = 0; i<Formula.size();i++) 
		{
			Dish dis = Formula.get(i);
			Object[] sets =  dis.Consumption.keySet().toArray();
			HashMap<Integer, Integer> mid_helper = new HashMap<Integer, Integer>();
			for(int j = 0 ; j < sets.length; j++) 
			{
				int n = j;
				List<Ingredient> p1 = products.stream().filter((Ingredient p) -> p.in_id == (int)sets[n]).collect(Collectors.toList());
				int x = p1.get(0).quantity;
				mid_helper.put((int)sets[n], x);
			}
			if(mid_helper.size() > 0) 
			{
				dis.Ingre_surplusquantity = mid_helper;
				Integer MinQuantity = -1;
				for(Integer key: mid_helper.keySet()) 
				{
					MinQuantity = mid_helper.get(key) <= MinQuantity || MinQuantity == -1 ? mid_helper.get(key)/dis.Consumption.get(key) :MinQuantity;
				}
				dis.quantity = MinQuantity;
				MenuInfo.add(dis);
			}
		}
	}
	
	public Dininghall(){
		
	}
	
	
	
}
