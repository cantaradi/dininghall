package com.station.model;

import java.util.HashMap;

import java.util.List;

public class Dish {
	public String dish_name;
	public String dish_id;
	public HashMap<Integer, Integer> Consumption; 
	public HashMap<Integer, Integer> Ingre_surplusquantity;
	public int quantity;
	public float price;
	
}
