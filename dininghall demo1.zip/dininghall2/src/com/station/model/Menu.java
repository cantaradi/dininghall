package com.station.model;

import java.util.ArrayList;
import java.util.HashMap;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;



public class Menu {
	
	/*@
	  @ public invariant menu_id > 0;
	  @*/
	public String menu_name;
	public int menu_id;
	public /*@ nullable @*/ List<Dish> menu_content;
	
	public Menu() 
	{
		
	}
	/**
	 * This method is used to check if a dish already exists in the menu.
	 * This method starts when there is a request to search whether a dish exists in the menu
	 * This method ends when return a query result after searching.
	 * @param id
	 * @return Boolean
	 */
	/*@
	  @ requires id != null;
	  @ ensures \result== (\exists int i; 0 <= i && i<menu_content.size(); menu_content.get(i).dish_id == id);
	 @*/
	public /*@ pure @*/ Boolean if_includedish(String id) 
	{
		try 
		{
			Dish dish =  menu_content.stream().filter((Dish p) -> p.dish_id == id).collect(Collectors.toList()).get(0);
			Boolean result = false;
			result = dish != null ? true : result;
			return result;
		}
		catch(Exception ee) 
		{
			return false;
		}
	}
	/**
	 * This method is used to add the dish chosen by manager into the menu.
	 * This method starts when there is a request to add a new dish with specific dish_id into the menu. 
	 * This method ends when the new selected dish is already added into the menu.
	 * @param id
	 * @return void
	 */
	/*@
	  @ requires id != null;
	  @ requires (\exists int i; 0 <= i && i<DefaultDishes.DishesList.size(); 
	  @   DefaultDishes.DishesList.get(i).dish_id == id && DefaultDishes.DishesList.get(i).quantity > 0);
	  @ requires !(if_includedish(id)); 
	  @ ensures if_includedish(id);
	 @*/
	public void add_dish(String id) throws Exception 
	{
			try 
			{
				if(menu_content == null) 
				{
					menu_content = new ArrayList<Dish>();
				}
				Dish dishT = Dininghall.MenuInfo.stream().filter((Dish dish) -> dish.dish_id.equals(id)).collect(Collectors.toList()).get(0);
				
				menu_content.add(dishT);
				System.out.println("add the name of:'" + dishT.dish_name + "' to the menu_content!");
				System.out.println("menu content:");
				for(int i=0;i<menu_content.size();i++){
					System.out.println((i+1)+menu_content.get(i).dish_name);
				}
				
			}
			catch(Exception ee) 
			{
				throw new Exception("can't find the dish from Manager.MenuInfo");
			}
	}
}
