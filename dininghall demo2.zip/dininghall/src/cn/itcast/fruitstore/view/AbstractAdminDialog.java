package cn.itcast.fruitstore.view;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import cn.itcast.fruitstore.tools.GUITools;
/**
 * this class has been created to manage windows
 */
@SuppressWarnings("serial")
public abstract class AbstractAdminDialog extends JDialog{
	//Define the components used by the interface as member variables
	private JLabel tableLabel = new JLabel("Menu");//title for menu table��
	private JScrollPane tablePane = new JScrollPane();//Scroll viewport
	protected JTable table = new JTable(); //create a table for dish
	private JLabel numberLabel = new JLabel("dish_id");//list id for dish
	private JLabel nameLabel = new JLabel("dish_name");//list name for dish��
	private JLabel priceLabel = new JLabel("price");//list price for dish��
	private JLabel unitLabel = new JLabel("quantity");//list quantity for dish��
/*	//adding dish function components
	protected JTextField addNumberText = new JTextField(6);//adding dish_id test boxes
	protected JTextField addNameText = new JTextField(6);//adding dish_name test boxes
	protected JTextField addPriceText = new JTextField(6);//adding price test boxes
	protected JTextField addUnitText = new JTextField(6);//adding quantity test boxes
	private JButton addBtn = new JButton("add dish");//adding dish button
*/	//change dish function components
	protected JTextField updateNumberText = new JTextField(6);//change dish_id test boxes
	protected JTextField updateNameText = new JTextField(6);//change dish_name test boxes
	protected JTextField updatePriceText = new JTextField(6);//change price test boxes
	protected JTextField updateUnitText = new JTextField(6);//change quantity test boxes
	private JButton updateBtn = new JButton("refresh menu");//change dish button
	//refresh menu function components
	protected JTextField FreNumberText = new JTextField(6);//add dish_id test boxes
	private JButton delBtn = new JButton("delete_dish");//refresh menu button	
	//construction function
	public AbstractAdminDialog() {
		this(null,true);
	}
	public AbstractAdminDialog(Frame owner, boolean modal) {
		super(owner, modal);
		this.init();// initialize
		this.addComponent();// add component
		this.addListener();// add listener
	}
	// initialize
	private void init() {
		this.setTitle("dining hall menu");// title
		this.setSize(800, 600);// window size and location
		GUITools.center(this);//Set the position of the window on the screen
		this.setResizable(false);// Fixed window size
	}	
	// add components
	private void addComponent() {		
		//cancel layout
		this.setLayout(null);		
		//title for table
		tableLabel.setBounds(365, 30, 80, 35);
		this.add(tableLabel);		
		//table
		table.getTableHeader().setReorderingAllowed(false);	//Column cannot be moved
		table.getTableHeader().setResizingAllowed(false); 	//Non-pull table
		table.setEnabled(false);							//Cannot change data
		tablePane.setBounds(60, 60, 650, 300);				
		tablePane.setViewportView(table);					//Viewport Load Table
		this.add(tablePane);		
		//Field title��
		numberLabel.setBounds(120, 350, 80, 35);	
		nameLabel.setBounds(230, 350, 80, 35);	
		priceLabel.setBounds(340, 350, 80, 35);	
		unitLabel.setBounds(450, 350, 80, 35);	
		this.add(numberLabel);
		this.add(nameLabel);
		this.add(priceLabel);
		this.add(unitLabel);		
		//add components
/*		addNumberText.setBounds(120, 380, 90, 35);
		addNameText.setBounds(230, 380, 90, 35);
		addPriceText.setBounds(340, 380, 90, 35);
		addUnitText.setBounds(450, 380, 90, 35);
		this.add(addNumberText);
		this.add(addNameText);
		this.add(addPriceText);
		this.add(addUnitText);
		addBtn.setBounds(560, 380, 120, 35);
		this.add(addBtn);*/		
		//change components
		updateNumberText.setBounds(120, 380, 90, 35);
		updateNameText.setBounds(230, 380, 90, 35);
		updatePriceText.setBounds(340, 380, 90, 35);
		updateUnitText.setBounds(450, 380, 90, 35);
		this.add(updateNumberText);
		this.add(updateNameText);
		this.add(updatePriceText);
		this.add(updateUnitText);
		updateBtn.setBounds(560, 380, 120, 35);
		this.add(updateBtn);		
		//refresh menu components
		delBtn.setBounds(560, 420, 120, 35);
		this.add(delBtn);
	}	
	private void addListener(){
		//delete button for monitoring
				delBtn.addActionListener(new ActionListener() {			
					@Override
					public void actionPerformed(ActionEvent e) {
						//call refresh menu function
						delete_dish();
					}
				});
	//delete button for monitoring
		updateBtn.addActionListener(new ActionListener() {			
				@Override
				public void actionPerformed(ActionEvent e) {
					//call refresh menu function
					refresh_menu();
				}
			});
		}	

	
	//query method
	public abstract void queryDish();
	public abstract void delete_dish();
	public abstract void refresh_menu();

}
