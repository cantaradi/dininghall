package cn.itcast.fruitstore.controller;
import java.awt.Frame;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import cn.itcast.fruitstore.domain.Dininghall;
import cn.itcast.fruitstore.domain.Dish;
import cn.itcast.fruitstore.domain.Menu;
import cn.itcast.fruitstore.service.AdminService;
import cn.itcast.fruitstore.view.AbstractAdminDialog;
/**
 * manager UI operation class
 */


@SuppressWarnings("serial")


public class display_menu extends AbstractAdminDialog {
	public /*@ nullable @*/ Menu menu = new Menu();
	public Dininghall dininghall = new Dininghall();
	//public String menu_id;
	public String date;
	//Define service classes to provide full-featured services
	private AdminService adminService = new AdminService();
	/**
	 * for the display_menu() method, it used to extract data in database and display the whole menu to customers. After run this method, it will return an arraylist of dishes, which contains dish_id,dish_name,price and quantity parameters.
	 * @param mid
	 * @param date
	 */
	// display_menu() JML
	/*@ 
	  @ requires menu.menu_id != null;
	  @ ensures menu != null;
	  @*/
	public void upload_menu(String mid, String date) 
	{
		menu.menu_id = date; 
	}
	//construct function
	public display_menu(Frame owner, boolean modal) {
		super(owner, modal);
		//create object to show data
		queryDish();
	}	
	//query method
	
	@Override
	public void queryDish() {
		//define title of table
		String[] thead = {"dish_id","dish_name","price(/$)","quantity"};
		//call query function in AdminSerice class
		ArrayList<Dish> dataList = adminService.queryItem();
		//call list2Array function，transfer list to array，which in order to assignment to JTable
		String[][] tbody = list2Array(dataList);
		//assign results into the table
		TableModel dataModel = new DefaultTableModel(tbody, thead);
		table.setModel(dataModel);
	}
	//Collect data into two-dimensional array method
	public String[][] list2Array(ArrayList<Dish> list){		
		//Define a two-dimensional array of JTable data based on FruitItem's model and collection data
		String[][] tbody = new String[list.size()][4];	
		for (int i = 0; i < list.size(); i++) {
			Dish dish = list.get(i);
			tbody[i][0] = dish.getNumber();
			tbody[i][1] = dish.getName();
			tbody[i][2] = dish.getPrice()+"";
			tbody[i][3] = dish.getquantity()+"";
		}		
		return tbody;
	}
	
	//change dish function
	@Override
	public void refresh_menu() {		
		//gain data
		String updateNumber = updateNumberText.getText();
		String updateName = updateNameText.getText();
		String updatePrice = updatePriceText.getText();
		String updatequantity = updateUnitText.getText();
		//use the update method in AdminService class
		boolean updateSuccess = adminService.refresh_menu(updateNumber,
				updateName, updatePrice, updatequantity);	
		//if change successfully
		if(updateSuccess) {
			//refresh window after change successfully
			queryDish();
		}else {
			//have a hint for not change successfully
			JOptionPane.showMessageDialog(this, "menu has not changed");
		}
	}
	@Override
	public void delete_dish() {		
		//use the delete method in adminService class
		boolean delSuccess = adminService.delete_dish();		
		//if delete successfully
		if(delSuccess) {
			//refresh window if delete successfully
			queryDish();
		}else {
			//if cannot add dish, popup a error message
			JOptionPane.showMessageDialog(this, "error");
		}
	}	


}