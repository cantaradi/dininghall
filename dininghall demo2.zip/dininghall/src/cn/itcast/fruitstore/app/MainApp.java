package cn.itcast.fruitstore.app;
import cn.itcast.fruitstore.controller.MainFrameController;
import cn.itcast.fruitstore.domain.*;
/**
 * Run program
 */
public class MainApp {
	public static void main(String[] args) {		
		new MainFrameController().setVisible(true);
	}
}
