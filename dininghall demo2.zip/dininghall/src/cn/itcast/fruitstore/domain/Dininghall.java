package cn.itcast.fruitstore.domain;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import cn.stcast.warehouse.dao.SqlTest;
import cn.itcast.fruitstore.domain.*;
public class Dininghall {
	public String dininghall_name="dininghall1";
	public static List<Dish> MenuInfo = new ArrayList<Dish>();
	public /*@ nullable @*/ Menu menu = new Menu();
	public List<Product> products;
	
	public void upload_menu(String mid, String date) 
	{
		menu.menu_id = date; 
		SqlTest sql = new SqlTest();
		this.products =  sql.select(1);
		ArrayList<Dish> Formula = DefaultDishes.DishesList; 
		for(int i = 0; i<Formula.size();i++) 
		{
			Dish dis = Formula.get(i);
			Object[] sets =  dis.Consumption.keySet().toArray();
			HashMap<Integer, Integer> mid_helper = new HashMap<Integer, Integer>();
			for(int j = 0 ; j < sets.length; j++) 
			{
				int n = j;
				List<Product> p1 = products.stream().filter((Product p) -> p.id == (int)sets[n]).collect(Collectors.toList());
				int x = p1.get(0).quantity;
				mid_helper.put((int)sets[n], x);
			}
			if(mid_helper.size() > 0) 
			{
				dis.Ingre_surplusquantity = mid_helper;
				Integer MinQuantity = -1;
				for(Integer key: mid_helper.keySet()) 
				{
					MinQuantity = mid_helper.get(key) <= MinQuantity || MinQuantity == -1 ? mid_helper.get(key)/dis.Consumption.get(key) :MinQuantity;
				}
				dis.quantity = MinQuantity;
				MenuInfo.add(dis);
			}
		}
	}
	
	
	
}
