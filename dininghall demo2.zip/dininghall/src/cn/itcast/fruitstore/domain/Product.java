package cn.itcast.fruitstore.domain;

public class Product {

	public int id;
	public /*@ nullable @*/ String name;
	public int quantity;

	public void setId(int id1) {
		this.id = id1;

	}

	public void setProductName(String product_name) {
		this.name = product_name;

	}

	public void setSalePrice(int quantity) {
		this.quantity = quantity;

	}

}
