package cn.itcast.fruitstore.domain;

import java.util.ArrayList;



import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class DefaultDishes {
	public static ArrayList<Dish> DishesList = GetDefaultDishes();

	public static Dish genDish(String dishname, String dishId, HashMap<Integer, Integer> li) {
		Dish dish = new Dish();
		dish.Consumption = li;
		dish.dish_id= dishId;
		dish.dish_name = dishname;
		dish.quantity = 0;
		return dish;
	}

	public static ArrayList<Dish> GetDefaultDishes() {
		
		ArrayList<Dish> list = new ArrayList<Dish>();
		list.add(genDish("Fried Chicken", "1", new HashMap<Integer, Integer>() {
			{
				put(3, 5);
				put(7, 2);
			}
		}));
		list.add(genDish("Boiled Fish in Hot Sauce", "2", new HashMap<Integer, Integer>() {
			{
				put(2, 2);
				put(6, 1);
			}
		}));
		list.add(genDish("Yu Shiang Pork", "3", new HashMap<Integer, Integer>() {
			{
				put(1, 2);
				put(7, 2);
				put(10, 2);
			}
		}));
		list.add(genDish("Pork with Green Peppers", "4", new HashMap<Integer, Integer>() {
			{
				put(2, 2);
				put(10, 2);
			}
		}));
		list.add(genDish("Cumin Beef", "5", new HashMap<Integer, Integer>() {
			{
				put(4, 2);
				put(5, 2);
			}
		}));
		list.add(genDish("Kung Po Chicken", "6", new HashMap<Integer, Integer>() {
			{
				put(1, 1);
				put(3, 4);
				put(5, 2);
			}
		}));

		list.add(genDish("Szechuan Spicy Rice Noodle", "7", new HashMap<Integer, Integer>() {
			{
				put(8, 1);
				put(9, 2);
			}
		}));
		list.add(genDish("Healthy Mushroom Rice Noodle", "8", new HashMap<Integer, Integer>() {
			{
				put(9, 2);
				put(11, 1);
			}
		}));
		list.add(genDish("Tomato Rice Noodle with Beef", "9", new HashMap<Integer, Integer>() {
			{
				put(4, 1);
				put(9, 2);
				put(12, 1);
			}
		}));
		list.add(genDish("Egg Roll","10", new HashMap<Integer, Integer>() {
			{
				put(2, 2);
				put(8, 2);
			}
		}));

		list.add(genDish("BBQ Pork Fried Rice", "11", new HashMap<Integer, Integer>() {
			{
				put(2, 2);
				put(10, 2);
			}
		}));
		list.add(genDish("Yang Chow Fried Rice", "12", new HashMap<Integer, Integer>() {
			{
				put(1, 2);
				put(2, 2);
			}
		}));
		list.add(genDish("Tomato Egg Soup", "13", new HashMap<Integer, Integer>() {
			{
				put(8, 2);
				put(12, 2);
			}
		}));

		list.add(genDish("Combo1", "14", new HashMap<Integer, Integer>() {
			{
				put(2, 2);
				put(4, 2);
			}
		}));
		list.add(genDish("Combo2", "15", new HashMap<Integer, Integer>() {
			{
				put(1, 2);
				put(10, 2);
			}
		}));

		list.add(genDish("Combo3", "16", new HashMap<Integer, Integer>() {
			{
				put(5, 2);
				put(6, 2);
			}
		}));
		return list;
	}

}
