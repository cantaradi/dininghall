package cn.itcast.fruitstore.tools;
import java.awt.Component;
import java.awt.Toolkit;
import javax.swing.JFrame;
/*
 * tool class
 */
public class GUITools {
	//default GUI provided by JAVA as tool class object
	static Toolkit kit = Toolkit.getDefaultToolkit();
	//Center specified component screen
	public static void center(Component c) {
		int x = (kit.getScreenSize().width - c.getWidth()) / 2;
		int y = (kit.getScreenSize().height - c.getHeight()) / 2;
		c.setLocation(x, y);
	}
	//Set the icon title for the specified window
	public static void setTitleImage(JFrame frame,String titleIconPath) {
		frame.setIconImage(kit.createImage(titleIconPath));
	} 
}
