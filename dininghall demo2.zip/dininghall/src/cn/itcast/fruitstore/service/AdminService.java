package cn.itcast.fruitstore.service;
import java.util.ArrayList;

import cn.itcast.fruitstore.dao.AdminDao;
import cn.itcast.fruitstore.domain.Dish;
import cn.itcast.fruitstore.domain.Menu;
/*
 * Administrator Service
 */
public class AdminService {
	private AdminDao adminDao = new AdminDao();	
	//Call dishmap hashmap
	//Inquiry service
	public ArrayList<Dish> queryItem() {
		//Call the Get All Data method of the Dao layer to get all the data
		ArrayList<Dish> data = adminDao.queryAllData();
		//return data
		return data;
	} 
	public ArrayList<Dish> display = queryItem();
	public  String delNumber;
	public /*@ nullable @*/ Menu menu = new Menu();
	public String date;
	
    /**
     * if_empty method is used to check if customers can order more this dish. It should use dish_id to check and it will return boolean type.
     * @param dish_id
     * @return
     */
	 //If_empty(dish_id) JML
	/*@ 
	  @ requires dish_id != null;
	  @ ensures \result == (\exists int i; 0 <= i && i<display.size(); display.get(i).dish_id == dish_id && display.get(i).quantity == 0);
	  @*/
	public /*@ pure @*/ boolean if_empty(String dish_id) {
		//Call the Get All Data method of the Dao layer to get all the data
			 ArrayList<Dish> display = queryItem();
				for (int i = 0; i < display.size(); i++) {
					Dish dish = display.get(i);
			//if the quantity of dish is equal to zero
			if(dish_id.equals(dish.getNumber())) {
				if(dish.getquantity() == 0){
					return true;
				}
			}
		}
				return false;	
		}
	
    /**
     * delete_dish method is used to delete the dish which quantity is equal to zero. It will loop all dishes in the menu and to check its quantity. It will return true when all of this dish are made.
     * @return
     */
	//delete_dish() JML
	/*@ 
	  @ requires menu.if_includedish(delNumber) == true;
	  @ requires if_empty(delNumber) == true;
	  @ ensures menu.if_includedish(delNumber) == false;
	  @*/
	//delete method
	public boolean delete_dish() {		
		//Call the Get All Data method of the Dao layer to get all the data
		ArrayList<Dish> display = queryItem();
		//Use the entered number to compare with all data
		for (int i = 0; i < display.size(); i++) {
			Dish dish = display.get(i);
			//if the quantity of dish is equal to zero
			if(dish.getquantity() == 0) {
				//Call the method of deleting the specified number data in the Dao layer
				String delNumber = dish.getNumber();
				adminDao.delete_dish(delNumber);
				
				//After deleting the data, return to add successfully
				return true;
			}
		}
		//If there is no data with the same number, it cannot be deleted
		return false;
	}
	
    /**
     * When the chef cooks any dishes,refresh_menu method is used to refresh the quantity of all dishes on the menu.It will use the dish_id,dish_name,price and quantity of this dish and renew these attributes of this dish.
     * @param dish_id
     * @param dish_name
     * @param price
     * @param quantity
     * @return
     */
	//refresh_menu() JML
	 /*@ 
	   @ requires menu.menu_id == date;
       @ ensures  !(\exists int i; 0 <= i && i < display.size(); 
       @                   (display.get(i).quantity == 0));
	   @*/

	//Update menu service
	public boolean refresh_menu(String dish_id, String dish_name,
			String price, String quantity) {		
		ArrayList<Dish> display = queryItem();
		for (int i = 0; i < display.size(); i++) {
			Dish dish = display.get(i);
			if(dish_id.equals(dish.getNumber())) {
				adminDao.delete_dish(dish_id);
				Dish thisdish = new Dish(dish_id, dish_name,
						Double.parseDouble(price), Integer.parseInt(quantity));
				adminDao.addItem(thisdish);
				return true;
			}
		}
		return false;
			}
}
