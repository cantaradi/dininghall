package cn.itcast.fruitstore.test;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import cn.itcast.fruitstore.view.AbstractAdminDialog;
/*
 * manager UI test class
 */
@SuppressWarnings("serial")
public class AbstractAdminDialogTest extends AbstractAdminDialog{
	//define construction function to initialize data
	public AbstractAdminDialogTest() {
		super();
		queryDish();//test data
	}	
	//add data to test table
	@Override
	public void queryDish() {
		String[] thead = new String[]{"dish_id","dish_name","price(/$)","quantity"};
		String[][] tbody = new String[][]{
				{"1","chicken wings","5.0","1"},
				{"2","King Eddy Burger","9.99","1"},
				{"3","Grilled Cheese","6.99","1"},
				{"4","The Earth Salad","13.99","1"}
				};
		TableModel data = new DefaultTableModel(tbody,thead);
		table.setModel(data);
	}
	@Override
	public void delete_dish() {
	}
	@Override
	public void refresh_menu() {
	}
    //define main function to run program
	public static void main(String[] args) {
		//create UI and show
		new AbstractAdminDialogTest().setVisible(true);
	}
}
