package cn.itcast.fruitstore.test;
import cn.itcast.fruitstore.view.AbstractMainFrame;
/**
 * main window test class
 */
@SuppressWarnings("serial")
public class AbstractMainFrameTest extends AbstractMainFrame {
	//define main function
	public static void main(String[] args) {
		new AbstractMainFrameTest().setVisible(true);
	}
	//Override the method of displaying the administrator interface in the parent class
	@Override
	public void showAdminDialog() {
		System.out.println("enter to the system");
	} 
}
