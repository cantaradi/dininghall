package cn.itcast.fruitstore.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
//import cn.itcast.fruitstore.data.DataBase;
import cn.itcast.fruitstore.domain.Dish;
import cn.itcast.fruitstore.tools.JDBCUtils;
/*
 * function to gain data from database
 */
public class AdminDao {
	// gain all data from database
	public ArrayList<Dish> queryAllData() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Dish> list = new ArrayList<Dish>();
		try {
			// connect to database
			conn = JDBCUtils.getConnection();
			// get the subject to statement
			stmt = conn.createStatement();
			// sent SQL sentence
			String sql = "SELECT * FROM menu1";
			rs = stmt.executeQuery(sql);
			// deal with outcome of data
			while (rs.next()) {
				Dish dish = new Dish();
				dish.setNumber(rs.getString("dish_id"));
				dish.setName(rs.getString("dish_name"));
				dish.setPrice(rs.getDouble("price"));
				dish.setquantity(rs.getInt("quantity"));
				list.add(dish);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return null;
	}
	//refresh menu
	//add dish
		public void addItem(Dish dish) {
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
			try {
				// connect to database
				conn = JDBCUtils.getConnection();
				// get the subject to statement
				stmt = conn.createStatement();
				// sent SQL sentence
				String sql = "INSERT INTO menu1(dish_id,dish_name,price,quantity)"
						+ "VALUES(" + dish.getNumber() + ",'" + dish.getName()
						+ "','" + dish.getPrice() + "','" + dish.getquantity()+ "')";
				int num = stmt.executeUpdate(sql);
				if (num > 0) {
					System.out.println("Insert data successfully!");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCUtils.release(rs, stmt, conn);
			}	
		}
	//delete_dish
	public void delete_dish(String delNumber) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// connect to database
			conn = JDBCUtils.getConnection();
			// get the subject to statement
			stmt = conn.createStatement();
			// sent SQL sentence
			String sql = "DELETE FROM menu1 WHERE dish_id=" + delNumber;
			int num = stmt.executeUpdate(sql);
			if (num > 0) {
             System.out.println("Data deleted successfully!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}
}
