package cn.stcast.warehouse.dao;

import cn.itcast.fruitstore.domain.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SqlTest {
	public void add(String product_name, double sale_price, double cost_price) {
		System.out.println(
				"product_name=" + product_name + "," + "sale_price=" + sale_price + "," + "cost_price=" + cost_price);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/DiningHall", "root", "1234");

			String sql = "INSERT INTO product(product_name,sale_price,cost_price) VALUE  (?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, product_name);
			preparedStatement.setDouble(2, sale_price);
			preparedStatement.setDouble(3, cost_price);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delete(int id) {
		System.out.println("id=" + id);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/DiningHall", "root", "1234");
			String sql = "DELETE FROM product WHERE id=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void update(int id, String product_name, double cutoff, double cost_price) {
		System.out.println("id=" + id + "," + "product_name=" + product_name);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection =
			DriverManager.getConnection("jdbc:sqlite://localhost:3306/station_online",
			"root", "admin");
			//Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/DiningHall", "root", "1234");
			String sql = "UPDATE product SET product_name=?,cutoff=?,cost_price=? WHERE id=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, product_name);
			preparedStatement.setDouble(2, cutoff);
			preparedStatement.setDouble(3, cost_price);
			preparedStatement.setInt(4, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Product> select(int id) {
		List<Product> products = new ArrayList();

		try {
			//Class.forName("org.sqlite.JDBC");
            //Connection connection = DriverManager.getConnection("jdbc:sqlite:db/huang.db");
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/DiningHall", "root", "1234");
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30);
			String sql = "SELECT * FROM ingredient_list";

			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				Product product = new Product();
				int id1 = resultSet.getInt("in_id");
				String product_name = resultSet.getString("in_name");
				int sale_price = resultSet.getInt("quantity");
				product.setId(id1);
				product.setProductName(product_name);
				product.setSalePrice(sale_price);
				products.add(product);
			}
			resultSet.close();
			statement.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return products;
	}

}
