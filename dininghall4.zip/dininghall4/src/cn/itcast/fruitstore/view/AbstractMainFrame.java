package cn.itcast.fruitstore.view;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import cn.itcast.fruitstore.tools.GUITools;
/**
 * main window class
 */
@SuppressWarnings("serial")
public abstract class AbstractMainFrame extends JFrame {
	//components
	private JLabel titleLabel = new JLabel(new ImageIcon("maxresdefault.jpg"));//image for dining hall
	private JButton btn = new JButton("enter");//button to enter to the system
	//Constructor
	public AbstractMainFrame() {
		this.init();// initialize
		this.addComponent();// add components
		this.addListener();// add monitor
	}	
	//initialize
	private void init() {
		this.setTitle("Welcome to dining hall system");//title
		this.setSize(600, 400);// window size and location
		GUITools.center(this);//fixed window size
		GUITools.setTitleImage(this, "timg.jpg");
		this.setResizable(false);// Fixed window size
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//using System exit function to exit
	}	
	//add components
	private void addComponent() {
		//The form uses the default border layout, and input picture to the north area
		this.add(this.titleLabel, BorderLayout.NORTH);
		//create JPanel object
		JPanel btnPanel = new JPanel();
		//Clear layout so components in JPanel can be customized
		btnPanel.setLayout(null);
		//Add a JPanel object to the form
		this.add(btnPanel);	
		//Define the boundary position
		btn.setBounds(240, 20, 120, 50);
		//add button to JPanel object
		btnPanel.add(btn);
	}
	//add monitor
	private void addListener() {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAdminDialog();
			}
		});
	}	
	//Show administrator interface method
	public abstract void showAdminDialog();
}
