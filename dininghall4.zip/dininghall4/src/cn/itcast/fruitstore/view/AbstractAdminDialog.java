package cn.itcast.fruitstore.view;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import cn.itcast.fruitstore.domain.DiningHall;
import cn.itcast.fruitstore.tools.GUITools;
/**
 * this class has been created to manage windows
 */
@SuppressWarnings("serial")
public abstract class AbstractAdminDialog extends JDialog{
	//Define the components used by the interface as member variables
	private JLabel tableLabel = new JLabel("Menu");//title for menu table��
	private JScrollPane tablePane = new JScrollPane();//Scroll viewport
	protected JTable table = new JTable(); //create a table for dish
	private JLabel numberLabel = new JLabel("dish_id");//list id for dish
	private JLabel nameLabel = new JLabel("dish_name");//list name for dish��
	private JLabel priceLabel = new JLabel("price");//list price for dish��
	private JLabel unitLabel = new JLabel("quantity");//list quantity for dish��
	private JLabel lblOrderLabel = new JLabel("No Order");
/*	//adding dish function components
	protected JTextField addNumberText = new JTextField(6);//adding dish_id test boxes
	protected JTextField addNameText = new JTextField(6);//adding dish_name test boxes
	protected JTextField addPriceText = new JTextField(6);//adding price test boxes
	protected JTextField addUnitText = new JTextField(6);//adding quantity test boxes
	private JButton addBtn = new JButton("add dish");//adding dish button
*/	//change dish function components
	protected JTextField updateNumberText = new JTextField(6);//change dish_id test boxes
	protected JTextField updateNameText = new JTextField(6);//change dish_name test boxes
	protected JTextField updatePriceText = new JTextField(6);//change price test boxes
	protected JTextField updateUnitText = new JTextField(6);//change quantity test boxes
	private JButton updateBtn = new JButton("refresh menu");//change dish button
	//refresh menu function components
	protected JTextField FreNumberText = new JTextField(6);//add dish_id test boxes
	private JButton delBtn = new JButton("delete_dish");//refresh menu button
	private JButton btnCreateOrder = new JButton("Create");//create order
	private final JButton btnChangeOrder = new JButton("Change");//change order
	private DiningHall dn=new DiningHall();//dining hall class
	private final JButton btnCancelOrder = new JButton("Cancel");//cancel order
	private JButton btnSubmitOrder = new JButton("Submit");//submit order
	//construction function
	public AbstractAdminDialog() {
		this(null,true);
	}
	public AbstractAdminDialog(Frame owner, boolean modal) {
		super(owner, modal);
		this.init();// initialize
		this.addComponent();// add component
		this.addListener();// add listener
	}
	// initialize
	private void init() {
		this.setTitle("dining hall menu");// title
		this.setSize(800, 600);// window size and location
		GUITools.center(this);//Set the position of the window on the screen
		this.setResizable(false);// Fixed window size
	}	
	// add components
	private void addComponent() {		
		//cancel layout
		getContentPane().setLayout(null);		
		//title for table
		tableLabel.setBounds(365, 30, 80, 35);
		getContentPane().add(tableLabel);		
		//table
		table.getTableHeader().setReorderingAllowed(false);	//Column cannot be moved
		table.getTableHeader().setResizingAllowed(false); 	//Non-pull table
		table.setEnabled(false);							//Cannot change data
		tablePane.setBounds(60, 60, 650, 300);				
		tablePane.setViewportView(table);					//Viewport Load Table
		getContentPane().add(tablePane);		
		//Field title��
		numberLabel.setBounds(120, 350, 80, 35);	
		nameLabel.setBounds(230, 350, 80, 35);	
		priceLabel.setBounds(340, 350, 80, 35);	
		unitLabel.setBounds(450, 350, 80, 35);	
		lblOrderLabel.setFont(new Font("SimSun", Font.PLAIN, 25));
		lblOrderLabel.setBounds(214, 453, 137, 50);
		getContentPane().add(numberLabel);
		getContentPane().add(nameLabel);
		getContentPane().add(priceLabel);
		getContentPane().add(unitLabel);		
		//add components
/*		addNumberText.setBounds(120, 380, 90, 35);
		addNameText.setBounds(230, 380, 90, 35);
		addPriceText.setBounds(340, 380, 90, 35);
		addUnitText.setBounds(450, 380, 90, 35);
		this.add(addNumberText);
		this.add(addNameText);
		this.add(addPriceText);
		this.add(addUnitText);
		addBtn.setBounds(560, 380, 120, 35);
		this.add(addBtn);*/		
		//change components
		updateNumberText.setBounds(120, 380, 90, 35);
		updateNameText.setBounds(230, 380, 90, 35);
		updatePriceText.setBounds(340, 380, 90, 35);
		updateUnitText.setBounds(450, 380, 90, 35);
		getContentPane().add(updateNumberText);
		getContentPane().add(updateNameText);
		getContentPane().add(updatePriceText);
		getContentPane().add(updateUnitText);
		updateBtn.setBounds(544, 380, 120, 35);
		getContentPane().add(updateBtn);
		getContentPane().add(lblOrderLabel);
		//refresh menu components
		delBtn.setBounds(560, 420, 120, 35);
		getContentPane().add(delBtn);
		delBtn.setBounds(544, 416, 120, 35);
		getContentPane().add(delBtn);
		btnCreateOrder.setBounds(544, 453, 120, 27);
		getContentPane().add(btnCreateOrder);
		btnChangeOrder.setBounds(544, 481, 120, 27);
		getContentPane().add(btnChangeOrder);
		btnCancelOrder.setBounds(667, 384, 113, 27);
		getContentPane().add(btnCancelOrder);
		btnSubmitOrder.setBounds(667, 420, 113, 27);
		getContentPane().add(btnSubmitOrder);
		
	}	
	private void addListener(){
		//delete button for monitoring
				delBtn.addActionListener(new ActionListener() {			
					@Override
					public void actionPerformed(ActionEvent e) {
						//call refresh menu function
						delete_dish();
					}
				});
	//delete button for monitoring
		updateBtn.addActionListener(new ActionListener() {			
				@Override
				public void actionPerformed(ActionEvent e) {
					//call refresh menu function
					refresh_menu();
				}
			});
		//create order
				btnCreateOrder.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String id_temp=updateNumberText.getText();
						String num_temp=updateUnitText.getText();
						String order_id_temp=dn.createOrder(id_temp, Integer.parseInt(num_temp));
						lblOrderLabel.setText(order_id_temp);
					}
				});
				//change order
				btnChangeOrder.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String id_temp=updateNumberText.getText();
						String num_temp=updateUnitText.getText();
						String order_temp=lblOrderLabel.getText();
						dn.changeOrder(order_temp, id_temp, Integer.parseInt(num_temp));
					}
				});
				//cancel order
				btnCancelOrder.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String order_temp=lblOrderLabel.getText();
						dn.cancelOrder(order_temp);
						lblOrderLabel.setText("No Order");
					}
				});
				//submit order
				btnSubmitOrder.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dn.submitOrder();
						lblOrderLabel.setText("No Order");
						
						//chef handle order
						dn.chef.handleOrder();
					}
				});
		}	

	
	//query method
	public abstract void queryDish();
	public abstract void delete_dish();
	public abstract void refresh_menu();

}
