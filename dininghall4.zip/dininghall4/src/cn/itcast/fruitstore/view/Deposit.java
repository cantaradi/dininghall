package cn.itcast.fruitstore.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.itcast.fruitstore.service.DepositMoney;

/*for deposit class, we could get the amount of money that the user wants to deposit. 
 * In this class, the amount_of_money()function will return a float value for the amount_of_money.
 */
public class Deposit implements ActionListener{
	static JTextField l;
	static JFrame frame;
	public void depositaction() { 
		JFrame frame=new JFrame("deposit");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Deposit c=new Deposit();
		JPanel P=new JPanel();
		JButton bconfirm;
		l=new JTextField(16);
		bconfirm=new JButton("confirm");
		bconfirm.addActionListener(c);
		P.add(bconfirm);
		P.add(l);
		frame.add(P);
        frame.setSize(800, 600);
        frame.show(); 
	}
	
	public float amount_of_money() {
		float amount_of_money=Float.parseFloat(l.getText());
		return amount_of_money;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		float balance=0;
		String s=e.getActionCommand();
		if (s.charAt(0)== 'c') {
			DepositMoney t=new DepositMoney();
			balance=t.depositMoneyFunction();
			JDialog d=new JDialog(frame,"balance");
			JLabel l=new JLabel("the balance is "+String.valueOf(balance));
			d.add(l);
			d.setSize(100,100);
			d.setVisible(true);
			}
	}

}
