package cn.itcast.fruitstore.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cn.itcast.fruitstore.service.Expend;

//for mainkey class, this will make a window with the selection of expend or deposit.
public class MainKey implements ActionListener{

	JFrame frame;
	public void mainkeyaction() {
		JFrame frame=new JFrame("the user account");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainKey m=new MainKey();
		JButton bexpend, bdeposit;
		bexpend=new JButton("expend");
        bdeposit=new JButton("deposit");
        JPanel P=new JPanel();
        bexpend.addActionListener(m);
        bdeposit.addActionListener(m);
        P.add(bexpend);
        P.add(bdeposit);
        frame.add(P);
        frame.setSize(800, 600);
        frame.show();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		float balance=0;
		float pricetotal=0;
		String s=arg0.getActionCommand();
		if (s.charAt(0)== 'd') {
			Deposit z=new Deposit();
			z.depositaction();
			z.actionPerformed(arg0);
		}else if(s.charAt(0)=='e'){
			Expend j=new Expend();
			balance=j.expendMoney()[0];
			pricetotal=j.expendMoney()[1];
			if(balance<0) {
				JDialog d=new JDialog(frame,"balance");
				JLabel l=new JLabel("you do not have enough money");
				d.add(l);
				d.setSize(100,100);
				d.setVisible(true);
			}else {
			JDialog d=new JDialog(frame,"balance and expend");
			JLabel l=new JLabel("the balance is "+String.valueOf(balance)+"the expend is"+String.valueOf(pricetotal));
			d.add(l);
			d.setSize(100,100);
			d.setVisible(true);
			}
		}
	}
}
