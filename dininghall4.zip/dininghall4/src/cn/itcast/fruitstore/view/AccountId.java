package cn.itcast.fruitstore.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*For accountid class, this is used to get the account id the user inputs. 
 * In this class, accountidd()function will return the account id.
 */
@SuppressWarnings("serial")
public class AccountId extends JFrame implements ActionListener{

	static JTextField b;
	public static void main(String[] args) {
		JFrame frame=new JFrame("the user accountid");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		AccountId c=new AccountId();
		JPanel P=new JPanel();
		JLabel account_id=new JLabel();
		JButton bconfirm;
		account_id.setText("account id:");
		b=new JTextField(16);
		bconfirm=new JButton("confirm");
		bconfirm.addActionListener(c);
		P.add(bconfirm);
		P.add(b);
		frame.add(P);
        frame.setSize(800, 600);
        frame.show();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String t;
		String s=e.getActionCommand();
		JFrame frame=new JFrame("the user account");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		if (s.charAt(0)== 'c') {
			t=Accountidd();
			int result = Integer.parseInt(t);
			/*@
			  @ requires result<=20;
			  @ ensures true;
			 @*/
			if (result>20) {
				JDialog d=new JDialog(frame,"account id");
				JLabel l=new JLabel("account is is not in the system");
				d.add(l);
				d.setSize(100,100);
				d.setVisible(true);
			}else {
			MainKey i=new MainKey();
			i.mainkeyaction();
			i.actionPerformed(e);
			}
		}
	}

	private String Accountidd() {
		// TODO Auto-generated method stub
		return null;
	}

	public String accountIdd() {
		  return b.getText();
	}
}
