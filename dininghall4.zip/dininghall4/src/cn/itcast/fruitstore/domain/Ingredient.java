package cn.itcast.fruitstore.domain;

public class Ingredient {
	/*@
	  @ public invariant in_id > 0;
	  @ public invariant quantity > 0;
	  @*/
	public int in_id;
	public String in_name;
	public int quantity;

	public void setId(int id1) {
		this.in_id = id1;

	}

	public void setProductName(String product_name) {
		this.in_name = product_name;

	}

	public void setSalePrice(int quantity) {
		this.quantity = quantity;

	}
}
