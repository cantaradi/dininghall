package cn.itcast.fruitstore.domain;

import java.util.ArrayList;
import java.util.Date;

import cn.itcast.fruitstore.data.OrderDetail;

public class Order {
	
	/**
	 * This class describe some important information of order
	 * @param order_id
	 * @param descroption
	 * @param price
	 * @param time
	 * @param status
	 */
	/*@
	  @ public invariant (\forall int i; i>=0&&i<orderlist.size();
	  @						(\forall int j;j>=0&&j<orderlist.size();
	  @							(orderlist.get(i)!=orderlist.get(j))
	  @							==>orderlist.get(i).order_id!=orderlist.get(j).order_id));
	  @ public invariant (description.size()>0 && description.size()<100);
	  @ public invariant (\exists DiningHall dn; time.toString().equals("null")==false
	  @						&& time.compareTo(dn.opentime)>0 
	  @						&& time.compareTo(dn.closedtime)<0);
	  @ protected invariant (price>=5 && price<=20);
	@*/
	protected /*@spec_public@*/ String order_id;
	protected /*@spec_public@*/ ArrayList<OrderDetail> description=new ArrayList<OrderDetail>(); 
	protected float price;
	protected /*@spec_public@*/ Date time;
	protected /*@spec_public@*/ boolean status;
	protected /*@spec_public@*/ ArrayList<Order> orderlist=new ArrayList<Order>();
}
