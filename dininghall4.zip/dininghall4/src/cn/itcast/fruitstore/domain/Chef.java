package cn.itcast.fruitstore.domain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import cn.itcast.fruitstore.data.OrderDetail;
import cn.itcast.fruitstore.tools.JDBCUtils;

public class Chef {
	/**
	 * the chef class describe the main inforamtion and action which 
	 * a chef need to have.
	 * @param chef_id
	 * @param chef_age
	 * @param chef_name
	 * @param order_number
	 */
	/*@
	 	@protected invariant (\forall Chef a,b; a!=b ==> a.chef_id!=b.chef_id);
	 	@protected invariant (chef_age>=18 && chef_age<=66);
	 	@protected invariant (chef_name!=null);
	 	@public invariant (order_number>=0);
	@*/
	protected String chef_id;
	protected int chef_age;
	protected String chef_name;
	protected /*@spec_public@*/ int order_number;
	private ArrayList<OrderDetail> order=new ArrayList<OrderDetail>();
	private /*@spec_public@*/ ArrayList<OnSale> onsaledishes=new ArrayList<OnSale>();
	private /*@spec_public@*/ ArrayList<OnPreparation> onpreparationdishes=new ArrayList<OnPreparation>();
	
	private static String selectorderdetailcode="select * from order_detail where order_id=?";
	private static String selectorderinfocode="select order_id from order_info where order_status=true";
	
	/**
	 * The chef need to cook the dishes and put them on sale. 
	 * so the chef need to move the dishes from onPreparaton to OnSale
	 * when the dish is finished, the number of corresponding ingredients also decrease
	 * @param dish_id
	 * @param quantity_of_dishes
	 * @return 
	 */
	/*@
	 	@ requires(\exists OnSale onsale; onsale.quantity==0)
	 	@		&&(\exists OnPreparation onpreparation; onpreparation.quantity>0);
	 	@ ensures (\exists OnSale onsale; onsale.quantity==\old(onsale.quantity)+quantity_of_dishes)
	 	@		&&(\exists OnPreparation onpreparation; 
	 	@			onpreparation.quantity==\old(onpreparation.quantity)-quantity_of_dishes
	 	@			&& (\forall Integer i; i>=0 && i<onpreparation.Ingre_surplusquantity.keySet().size();
	 	@				onpreparation.Ingre_surplusquantity.get(i)==\old(onpreparation.Ingre_surplusquantity.get(i))
	 	@				-(onpreparation.Consumption.get(i)*quantity_of_dishes)));
	@*/
	public void increase(String dish_id,int quantity_of_dishes)
	{
		//move dishes from onpreparation to onsale
		for(OnPreparation op:onpreparationdishes)
		{
			if(op.dish_id==dish_id)
			{
				for(OnSale os:onsaledishes)
				{
					if(os.dish_id==op.dish_id)
					{
						os.quantity+=(quantity_of_dishes);
						op.quantity-=(quantity_of_dishes);
						break;
					}
				}
				
				//recduce the number of Ingre_surplusquantity, other dish which have same inggedient also need to decrease
				for(Integer keycon:op.Consumption.keySet())
				{
					for(Integer keyingre:op.Ingre_surplusquantity.keySet())
					{
						if(keycon==keyingre)
						{
							int quantity=op.Ingre_surplusquantity.get(keyingre)-(op.Consumption.get(keyingre)*quantity_of_dishes);
							op.Ingre_surplusquantity.put(keyingre, quantity);
							break;
						}
					}
				}
			}
		}
	}
	
	/**
	 * The chef also need to sell the dishes. it should decrese the number of OnSale.
	 * @param order_id
	 * @param quantity_of_dishes
	 * @return
	 */
	/*@
			@ requires(\exists Order order; order.order_id==order_id && order.status==true)
			@		&&(\exists OnSale onhall, onsale; onhall.quantity<=onsale.quantity);
			@ ensures(order_number==\old(order_number)-1)
			@		&&(\exists OnSale onhall,onsale; onsale.quantity==\old(onsale.quantity)-onhall.quantity);
	@*/
	public void decrease(String order_id, int quantity_of_dishes)
	{
		//connect to database
		try {
			Connection conn=JDBCUtils.getConnection();
			//if order status is true, chef can handle the order
			
			//according to order detail, select from database 
			PreparedStatement ps=conn.prepareStatement(selectorderdetailcode);
			ps.setString(1, order_id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				OrderDetail od=new OrderDetail();
				od.setDish_id(rs.getString(2));
				od.setQuantity(rs.getInt(3));
				order.add(od);
			}
			
			//decrease the quantity of onsale
			for(OrderDetail od:order)
			{
				for(OnSale os:onsaledishes)
				{
					if(od.getDish_id()==os.dish_id)
					{
						os.quantity-=(od.getQuantity());
						break;
					}
				}
			}
			
			//chef reduce the order number
			this.order_number-=1;
			
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Initializing the onsale dishes and onpreparation dishes
	public void initDishes(ArrayList<Dish> menulist)
	{
		//init onpreparation dishes
		for(Dish dish:menulist)
		{
			OnPreparation op=new OnPreparation();
			op.dish_id=dish.dish_id;
			op.dish_name=dish.dish_name;
			op.price=dish.price;
			op.quantity=dish.quantity;
			op.cooking_time=20;
			
			Iterator<?> itconsumption=dish.Consumption.entrySet().iterator();
			while(itconsumption.hasNext())
			{
				Entry<?, ?> entry=(Entry<?, ?>)itconsumption.next();
				Integer key=(Integer) entry.getKey();
				op.Consumption.put(key, dish.Consumption.get(key));
			}
			
			Iterator<?> itingre=dish.Ingre_surplusquantity.entrySet().iterator();
			while(itingre.hasNext())
			{
				Entry<?, ?> entry=(Entry<?, ?>)itingre.next();
				Integer key=(Integer) entry.getKey();
				op.Ingre_surplusquantity.put(key, dish.Ingre_surplusquantity.get(key));
			}
			
			onpreparationdishes.add(op);
		}
		
		//init onsale dishes
		for(OnPreparation op:onpreparationdishes)
		{
			OnSale os=new OnSale();
			os.dish_id=op.dish_id;
			os.dish_name=op.dish_name;
			os.price=op.price;
			os.quantity=op.quantity;
			
			Iterator<?> itconsumption=op.Consumption.entrySet().iterator();
			while(itconsumption.hasNext())
			{
				Entry<?, ?> entry=(Entry<?, ?>)itconsumption.next();
				Integer key=(Integer) entry.getKey();
				os.Consumption.put(key, 0);
			}
			
			Iterator<?> itingre=op.Ingre_surplusquantity.entrySet().iterator();
			while(itingre.hasNext())
			{
				Entry<?, ?> entry=(Entry<?, ?>)itingre.next();
				Integer key=(Integer) entry.getKey();
				os.Ingre_surplusquantity.put(key,0);
			}
			
			onsaledishes.add(os);
		}
	}
	
	//chef need to handle the order
	public void handleOrder()
	{
		//chef should check the paid order, order_status=true
		try {
			Connection conn=JDBCUtils.getConnection();
			PreparedStatement ps=conn.prepareStatement(selectorderinfocode);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String order_id_temp=rs.getString(1);
				decrease(order_id_temp,2);
				increase("2",100);  
			}
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
