package cn.itcast.fruitstore.domain;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.itcast.fruitstore.view.AccountId;
@SuppressWarnings("serial")
public class Manager extends AccountId implements ActionListener{
	
	/*@
	   @ public invariant manager_id != null;
	   @ public invariant (\forall int i; 0 <= i && i<dininghall.MenuInfo.size();
	   @   (\forall int j; 0 <= j && j< dininghall.MenInfo.size();
	   @       dininghall.MenInfo.get(j) != dininghall.MenInfo.get(i) 
	   @           ==> dininghall.MenInfo.get(j).manager_id != dininghall.MenInfo.get(i).manager_id));
	 @*/
	public String manager_id;
	public Menu menu=new Menu();
	JLabel label;
	JLabel label2;
	JTextField datetext;
	JButton uploadmenuBt;
	JButton confirmBt;
	JButton cancelBt;
	public DiningHall dininghall;
	JPanel menuPanel;

	public Manager(DiningHall hall){
		dininghall = hall;
		uploadmenuBt = new JButton("Upload menu");
		uploadmenuBt.setSize(170, 130);
		uploadmenuBt.setLocation(50, 130);
		this.add(uploadmenuBt);
		confirmBt=new JButton("confirm");
		confirmBt.setSize(100,30);
		confirmBt.setLocation(40, 240);
		confirmBt.addActionListener(this);
		this.add(confirmBt);
		confirmBt.setVisible(false);
		cancelBt=new JButton("cancel");
		cancelBt.setSize(100,30);
		cancelBt.setLocation(180, 240);
		cancelBt.addActionListener(this);
		this.add(cancelBt);
		cancelBt.setVisible(false);
		
		datetext=new JTextField();
		datetext.setSize(100,30);
		datetext.setLocation(200, 120);
		this.add(datetext);
		datetext.setVisible(false);
		
		label = new JLabel("Please enter today's date:");
		label.setSize(190, 190);
		label.setLocation(30, 40);
		this.add(label); 
		label.setVisible(false);
		
		label2 = new JLabel("Menu has already been generated for today, no more upload menu operation for today.");
		label2.setSize(700, 200);
		label2.setLocation(30, 40);
		this.add(label2); 
		label2.setVisible(false);
		
		menuPanel = new JPanel();
		menuPanel.setVisible(false);
		this.add(menuPanel);
		this.setSize(330,440);
		this.setVisible(true);
		uploadmenuBt.addActionListener(this);
		

		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bt=(JButton)e.getSource();
		if(bt.getText().equals("Upload menu"))
		{
			bt.setVisible(false);
			confirmBt.setVisible(true);
			cancelBt.setVisible(true);
			datetext.setVisible(true);
			label.setVisible(true);
		}
		else if(bt.getText().equals("confirm")){
			bt.setVisible(false);
			cancelBt.setVisible(false);
			datetext.setVisible(false);
			label.setVisible(false);
			this.setSize(600,600);
			String date = datetext.getText().toString();
			dininghall.upload_menu(manager_id, date);
			menuPanel.setLayout(new GridLayout(5, 5, 10, 10));
			for(Dish dish : dininghall.MenuInfo) 
			{
				JPanel card = makeMakepanel(dish);
				menuPanel.add(card);
			}
			JButton submitButton = new JButton("submit");
			submitButton.setSize(300,300);
			menuPanel.add(submitButton);
			menuPanel.setVisible(true);
			submitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	JOptionPane.showMessageDialog(null, "Today's menu has been generated successfully!", "SUCCESS",JOptionPane.PLAIN_MESSAGE);
	            	menuPanel.setVisible(false);
	            	label2.setVisible(true);
	            	
	            }
	        });
			
		}
		else if(bt.getText().equals("cancel")){
			bt.setVisible(false);
			confirmBt.setVisible(false);
			datetext.setVisible(false);
			label.setVisible(false);
			uploadmenuBt.setVisible(true);
		}
	}
	
	private String GetDishProductName(Dish dish) 
	{
		String str = "ingredients:";
		for(Integer c : dish.Consumption.keySet() ) 
		{
			Product pro = dininghall.products.stream().filter((Product p) -> p.id == c.intValue()).collect(Collectors.toList()).get(0);	
			if(str == "ingredients:") 
			{
				str += pro.name;
			}
			else 
			{
				str += ", " + pro.name;
			}
			
		}
		return str;
	}
	
	public JPanel makeMakepanel(Dish dish) 
	{
		
		JPanel MenuCard = new JPanel(new GridLayout(3, 1, 10, 10));
		MenuCard.setSize(600, 600);
		
		JLabel dish_name = new JLabel();
		dish_name.setText(dish.dish_name);
		MenuCard.add(dish_name);
		
		JLabel dish_component = new JLabel();
		dish_component.setText(GetDishProductName(dish));
		MenuCard.add(dish_component);
		
		JLabel dish_quantity = new JLabel();
		dish_quantity.setText("dish quantity:" + String.valueOf(dish.quantity));
		MenuCard.add(dish_quantity);

		MenuCard.add(dish_quantity, BorderLayout.CENTER);
		MenuCard.setBackground(Color.WHITE);
		MenuCard.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try 
				{
					if(dininghall.menu.if_includedish(dish.dish_id)) 
					{   
						JOptionPane.showMessageDialog(null, "The dish already exists in the menu. Can't add it again!", "ERROR",JOptionPane.ERROR_MESSAGE); 
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Add the dish " + dish.dish_name + " to the menu successfully!", "SUCCESS",JOptionPane.PLAIN_MESSAGE);
						dininghall.menu.add_dish(dish.dish_id);
					}
				}
				catch(Exception e)
				{
					System.out.println(e.toString());
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				MenuCard.setBackground(Color.WHITE);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				MenuCard.setBackground(Color.GRAY);
			}
			});
		return MenuCard;
	}
}
