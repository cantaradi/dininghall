package cn.itcast.fruitstore.domain;

public class OnSale extends Dish{

}
