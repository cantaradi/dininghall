package cn.itcast.fruitstore.domain;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import cn.itcast.fruitstore.data.OrderDetail;
import cn.itcast.fruitstore.tools.JDBCUtils;
import cn.itcast.fruitstore.tools.OtherFunction;
import cn.stcast.warehouse.dao.SqlTest;
public class DiningHall {
	
	/**
	 * The dining hall should have the open time and close time to specify
	 * thr working hours
	 * @param opentime
	 * @param closedtime
	 */
	/*@
	 	@ public invariant (opentime!=null);
	 	@ public invariant (closedtime!=null && closedtime.compareTo(opentime)>0);
	 @*/
	protected /*@spec_public@*/ Date opentime;
	protected /*@spec_public@*/ Date closedtime;
	private /*@spec_public@*/ Order order_temp=new Order();
	public Chef chef=new Chef();
	//random number range
	private static int min=10000000;
	private static int max=99999999;
	//menulist for test
	public String dininghall_name="dininghall1";
	public static List<Dish> MenuInfo = new ArrayList<Dish>();
	public /*@ nullable @*/ Menu menu = new Menu();
	public ArrayList<Manager> MenInfo=new ArrayList<Manager>();
	public List<Product> products;
	//SQL operation
	private String insertorderinfocode="insert into order_info(account_id, order_id,price,time,order_status) values(?,?,?,?,?)";
	private String insertorderdetailcode="insert into order_detail(order_id,dish_id,quantity) values(?,?,?)";
	private String selectdishcode="select * from dish";
	
	/**
	 * The upload menu function is used by the manager to choose dishes for today and generate today's menu. 
	 * This method starts when a manager logs into her account, clicks the “Upload menu”button and enters today’s date in her terminal. 
	 * This method ends when a menu including all the dishes chosen by the manager is formed
	 * @param mid
	 * @param date
	 * @return void
	 */
	/*@
	  @ requires date != null;
	  @ requires (\exists Manager m; m.manager_id == mid);
	  @ requires menu.menu_content == null;
	  @ ensures menu.menu_id == date;
	  @ ensures DefaultDishes.DishesList.containsAll(menu.menu_content);
	  @ ensures (\forall int i; 0 <= i && i<menu.menu_content.size(); menu.if_includedish(menu.menu_content.get(i).dish_id) && menu.menu_content.get(i).quantity > 0);
	  @*/
	public void upload_menu(String mid, String date) 
	{
		menu.menu_id = date; 
		SqlTest sql = new SqlTest();
		this.products =  sql.select(1);
		ArrayList<Dish> Formula = DefaultDishes.DishesList; 
		for(int i = 0; i<Formula.size();i++) 
		{
			Dish dis = Formula.get(i);
			Object[] sets =  dis.Consumption.keySet().toArray();
			HashMap<Integer, Integer> mid_helper = new HashMap<Integer, Integer>();
			for(int j = 0 ; j < sets.length; j++) 
			{
				int n = j;
				List<Product> p1 = products.stream().filter((Product p) -> p.id == (int)sets[n]).collect(Collectors.toList());
				int x = p1.get(0).quantity;
				mid_helper.put((int)sets[n], x);
			}
			if(mid_helper.size() > 0) 
			{
				dis.Ingre_surplusquantity = mid_helper;
				Integer MinQuantity = -1;
				for(Integer key: mid_helper.keySet()) 
				{
					MinQuantity = mid_helper.get(key) <= MinQuantity || MinQuantity == -1 ? mid_helper.get(key)/dis.Consumption.get(key) :MinQuantity;
				}
				dis.quantity = MinQuantity;
				MenuInfo.add(dis);
			}
		}
	}
	
	/**
	 * Create the order, user can only choose the order on the menu. It can generate an order ID automatically. 
	 * @param dish_id
	 * @param quantity
	 * @return order_id
	 */
	
	/*@
	  @ requires (\exists OnSale menu_onsale; menu_onsale.dish_id==dish_id
	  @			  && quantity>0
	  @			  && quantity< menu_onsale.quantity);
	  @ ensures (\exists Chef user_order_chef; user_order_chef.order_number
	  @			  == \old(user_order_chef.order_number)+1)
	  @		      && (\exists Order user_order; user_order.order_id==order_temp.order_id);
	@*/
	public String createOrder(String dish_id,int quantity)
	{
		//generate order ID
		order_temp.order_id=OtherFunction.generateID(min, max);
		
		//order dishes
		OrderDetail orderdetail=new OrderDetail();
		orderdetail.setDish_id(dish_id);
		orderdetail.setQuantity(quantity);
		order_temp.description.add(orderdetail);
	
		return order_temp.order_id;
	}
	
	/**
	 * User can change thge dishes in the order.the dishes must be on sale and have enough numbers.
	 * @param order_id
	 * @param dish_id
	 * @param quantity
	 * @return
	 */
	/*@
		  @ requires (\exists Order user_order; user_order.order_id==order_id)
		  @		  	&& (\exists OnSale menu_onsale; menu_onsale.dish_id==dish_id
	  @			&& quantity>0
	  @			&& quantity<= menu_onsale.quantity);
		  @ ensures (\exists Order user_order; user_order.description.size()
		  @			!=\old(user_order.description.size())
		  @		  	|| user_order.description.size()==\old(user_order.description.size()));
	@*/
	public void changeOrder(String order_id, String dish_id, int quantity)
	{
		
		for(int i=0;i<order_temp.description.size();i++)
		{
			OrderDetail orderdetail_temp=order_temp.description.get(i);
			//the dishes have already been in the order.
			if(orderdetail_temp.getDish_id().equals(dish_id)==true)
			{
				//customer removes this dish.
				if(orderdetail_temp.getQuantity()+quantity<=0)
					order_temp.description.remove(i);
				//customer adds or deccrases the number of dish.
				else
				{
					orderdetail_temp.setQuantity(orderdetail_temp.getQuantity()+quantity);
					order_temp.description.set(i, orderdetail_temp);
				}
			}
			//the dishes have not been in the order 
			else
			{
				OrderDetail orderdetail_temp1=new OrderDetail();
				orderdetail_temp1.setDish_id(dish_id);
				orderdetail_temp1.setQuantity(quantity);
				order_temp.description.add(orderdetail_temp1);
			}
		}
	}
	
	/**
	 * the Use is allowed to cancel the order if they want to. the order_id should be deleted
	 * @param order_id
	 * @return
	 */
	/*@
			@requires (\exists Order user_order; user_order.order_id==order_id);
			@ensures (\forall Order user_order; user_order.order_id!=order_id);
	@*/
	public void cancelOrder(String order_id)
	{
		order_temp.description=new ArrayList<OrderDetail>();
		order_temp=new Order();
	}
	
	//check out dish and inesert order inforamtion and detail into dining hall database
	public void submitOrder()
	{
		Connection conn=null;
		Date date=new Date();
		float totalprice=0;
		try {
			//connect database
			conn=JDBCUtils.getConnection();
			
			//check out dishes and calculate the total price.
			for(OrderDetail od:order_temp.description)
			{
				for(Dish dish:MenuInfo)
				{
					if(od.getDish_id()==dish.dish_id)
					{
						totalprice+=(dish.price*od.getQuantity());
						break;
					}
				}
			}
			order_temp.price=totalprice;
			
			//inesrt order infomation into database
			PreparedStatement ps=conn.prepareStatement(insertorderinfocode);
			ps.setString(1, OtherFunction.generateID(1, 10));
			ps.setString(2, order_temp.order_id);
			ps.setFloat(3, order_temp.price);
			ps.setTimestamp(4, new Timestamp(date.getTime()));
			ps.setBoolean(5, false);
			ps.executeUpdate();
			
			//insert order detail into database
			PreparedStatement ps1=conn.prepareStatement(insertorderdetailcode);
			for(OrderDetail od:order_temp.description)
			{
				ps1.setString(1, order_temp.order_id);
				ps1.setString(2, od.getDish_id());
				ps1.setInt(3,od.getQuantity());
				ps1.executeUpdate();
			}
			
			//chef order_number increase by 1
			chef.order_number+=1;
			
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
