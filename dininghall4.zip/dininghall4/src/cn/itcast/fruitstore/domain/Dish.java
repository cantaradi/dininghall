package cn.itcast.fruitstore.domain;
import java.util.ArrayList;
import java.util.HashMap;
import cn.itcast.fruitstore.dao.AdminDao;
import java.util.List;

/*
 * dish model to store dish information
 */
public class Dish {
	
	/**
	  * Dish_id must be unique; It can be used for identifying each dish.Each dish should have its name.The quantity of dish can be greater and equal to zero.The price of dish can be greater and equal to zero.
	  * @param dish_id
	  * @param dish_name
	  * @param price
	  * @param quantity
	  */
	//dish invariant
	/*@
	  @ public invariant (\exists Integer i; Ingre_surplusquantity.get(i)==0 
	  @ 					==> \forall OnPreparation onpreparation; onpreparation.dish_id!=dish_id);//peoblems and errors
	  @ public invariant (price>0 && price>=2);
      @ public invariant (\forall int i; 0 <= i && i <display.size();
      @              (\forall int j; 0 <= j && j <display.size();
      @                 !(display.get(i).dish_id.equals(display.get(j).dish_id)) && display.get(i).dish_id !=null &&
      @                             display.get(j).dish_id != null));
      @ 
      @ public invariant (\forall int i; 0 <= i && i <display.size();
      @                     (display.get(i).dish_name != null && display.get(i).quantity >= 0));
      @*/
	//define attributes
	public String dish_id;//dish_id
	public String dish_name; //dish_name
	public double price; //price
	public int quantity;  //quantity
	public  String delNumber;
	private AdminDao adminDao = new AdminDao();	
	//public ArrayList<Dish> display = adminDao.queryAllData();
	public HashMap<Integer, Integer> Consumption; // dish_id: how much ingredients will be used to make one dish
	public HashMap<Integer, Integer> Ingre_surplusquantity; // ingredient_id: remaining quanity of ingredient 
	//new a function
	public Dish() {
	} 
	public Dish(String dish_id, String dish_name, double price, int quantity) {
		super();
		this.dish_id = dish_id;
		this.dish_name = dish_name;
		this.price = price;
		this.quantity = quantity;
	}
	//using "get" and "set" function to get attributes
	public String getNumber() {
		return dish_id;
	}
	public void setNumber(String dish_id) {
		this.dish_id = dish_id;
	}
	public String getName() {
		return dish_name;
	}
	public void setName(String dish_name) {
		this.dish_name = dish_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getquantity() {
		return quantity;
	}
	public void setquantity(int quantity) {
		this.quantity = quantity;
	}

}
