package cn.itcast.fruitstore.domain;

public class OnPreparation extends Dish{
/*@
 	@ protected invariant (cooking_time>0 && cooking_time <20);
 @*/
	protected int cooking_time;
}
