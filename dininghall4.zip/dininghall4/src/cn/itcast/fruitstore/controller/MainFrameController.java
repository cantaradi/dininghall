package cn.itcast.fruitstore.controller;
import cn.itcast.fruitstore.view.AbstractMainFrame;
/**
 * main interface operation
 */
@SuppressWarnings("serial")
public class MainFrameController extends AbstractMainFrame {
	@Override
	public void showAdminDialog() {
		//Create an administrator interface in this method and display
		//this is the parent window (main interface) true: set to modal window display
		new display_menu(this, true).setVisible(true);
	}
}
