package cn.itcast.fruitstore.data;

public class OrderDetail {
	protected String dish_id;
	protected int quantity;
	
	public String getDish_id() {
		return dish_id;
	}
	public void setDish_id(String dish_id) {
		this.dish_id = dish_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
