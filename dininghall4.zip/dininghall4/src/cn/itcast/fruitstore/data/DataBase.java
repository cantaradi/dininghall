package cn.itcast.fruitstore.data;
import java.util.ArrayList;
import cn.itcast.fruitstore.domain.Dish;
/**
 * store data
 */
public class DataBase {
	public static ArrayList<Dish> data = new ArrayList<Dish>();	
	//initialize
	static {		
		data.add(new Dish("1","chiken wings",5.0,100000));
	}
}
