package cn.itcast.fruitstore.tools;

import java.util.Random;

import cn.itcast.fruitstore.domain.Dish;

public class OtherFunction {
	public static String generateID(int min,int max)
	{
		Random random=new Random();
		int id=random.nextInt(max)%(max-min+1)+min;
		return String.valueOf(id);
	}
	
	public void addingredient(Dish dish)
	{
		
	}
}
