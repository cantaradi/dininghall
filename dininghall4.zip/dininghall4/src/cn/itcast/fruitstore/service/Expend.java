package cn.itcast.fruitstore.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import cn.itcast.fruitstore.tools.JDBCUtils;
import cn.itcast.fruitstore.view.AccountId;

/*for expend class, we will use the price of order as one parameter. we will get oldbalance from database, 
 * and use oldbalance subtract the price of order to get the new balance. 
 * expendmoney() function will return an Array for the price of order and newbalance for the user.
*/
public class Expend {

	/**
	 * 
	 * @return ar
	 */
	public Float[] expendMoney()
	{
		Float ar[]=new Float[2];
		try {
			Connection conn=JDBCUtils.getConnection();
			ar=getbalance(conn);
			//  deletedata(conn);
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar;
	}
	
	/**
	 * 
	 * @param conn
	 * @return ar
	 */
	public Float[] getbalance(Connection conn) {
		float balance=0;
		float pricetotal=0;
		try {
			PreparedStatement psql;
			Statement stmt=conn.createStatement();
			ResultSet rs;
			psql=conn.prepareStatement("update account_detail set balance=? where account_id=?");
			AccountId u=new AccountId();
			String account_id=u.accountIdd();
			rs=stmt.executeQuery("SELECT price FROM order_info WHERE account_id="+account_id);
			ArrayList<Float> price=new ArrayList<Float>();
			while (rs.next()) {
				Float price1=rs.getFloat("price");
				price.add(price1);
			}
			for (int index=0;index<price.size();index++) {
				pricetotal=pricetotal+price.get(index);
			}
			rs=stmt.executeQuery("SELECT balance FROM account_detail WHERE account_id="+account_id);
			Float[] oldbalance=new Float[1];
			while (rs.next()) {
				Float oldbalance1=rs.getFloat("balance");
				oldbalance[0]= oldbalance1;
			}
			/*@
			 @ requires account_id!=null && pricetotal<=balance ;
			 @ ensures balance==\old(balance)-pricetotal;
			 */ 
			balance=oldbalance[0]-pricetotal;
			psql.setFloat(1,balance);
			psql.setString(2,account_id);
			psql.executeUpdate();
			psql.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("data has been updated");
		}
		Float ar[]=new Float[2];
		ar[0]=balance;
		ar[1]=pricetotal;
		return ar;
	}
	
	/**
	 * @param conn
	 * @return
	 */
	public void deletedata(Connection conn) {
		try {
		PreparedStatement psql;
		ResultSet rs;
		AccountId u=new AccountId();
		String account_id=u.accountIdd();
	    psql=conn.prepareStatement("DELETE FROM order_info WHERE account_id=?");
	    psql.setString(1, account_id);
	    psql.executeUpdate();
	    psql.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("data has been deleted");
		}	
	}
}
