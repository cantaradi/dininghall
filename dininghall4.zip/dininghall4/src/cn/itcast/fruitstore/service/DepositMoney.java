package cn.itcast.fruitstore.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import cn.itcast.fruitstore.tools.JDBCUtils;
import cn.itcast.fruitstore.view.AccountId;
import cn.itcast.fruitstore.view.Deposit;

/*For depositmoney class, we will get oldbalance from database.
 * the parameter we will use is the amount of money. it will return the newbalnce after deposit the money.
 */
public class DepositMoney {
	
	
	/*@
	 @ invariant (\forall float balance;balance>=0);
	*/
	/**
	 * @param amount_of_money
	 * @return balance
	 */
	public float depositMoneyFunction()
	{
		float balance=0;
		try {
			Connection conn=JDBCUtils.getConnection();
			insertdata(conn);
			balance=updatedata(conn);
			conn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balance;
	}
	
	/**
	 * @param conn
	 * @return balance
	 */
	public void insertdata(Connection conn) {
		try {
			PreparedStatement psql=conn.prepareStatement("insert into account_detail(account_id,balance)"+"values(?,?)");
			int i=1;
			while (i<=20) {
				i++;
				psql.setInt(1,i);
				psql.setFloat(2,0);
				psql.executeUpdate();
			}
			psql.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("data is inserted succesfully");
		}
	}
	
	/**
	 * @param conn
	 * @return balance
	 */
	public float updatedata(Connection conn) {
		float balance=0;
		try {
			PreparedStatement psql;
			Statement stmt=conn.createStatement();
			ResultSet rs;
			psql=conn.prepareStatement("update account_detail set balance=? where account_id=?");
			AccountId u=new AccountId();
			Deposit o=new Deposit();
			String account_id=u.accountIdd();
			Float amount_of_money= o.amount_of_money();
			rs=stmt.executeQuery("SELECT balance FROM account_detail WHERE account_id="+account_id);
			Float[] oldbalance=new Float[1];
			while (rs.next()) {
				Float oldbalance1=rs.getFloat("balance");
				oldbalance[0]= oldbalance1;
			}
			/*@ 
			 @ requires  amount_of_money>0 && account_id!=null;
			 @ ensures balance==\old(balance)+amount_of_money;
			 */
			balance=oldbalance[0]+amount_of_money;
			System.out.println(oldbalance[0]);
			System.out.println(balance);
			psql.setFloat(1,balance);
			psql.setString(2,account_id);
			psql.executeUpdate();
			psql.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("data has been updated");
		}
		return balance;
	}
	
}
